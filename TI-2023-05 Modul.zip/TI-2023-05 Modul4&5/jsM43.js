function pesan() {
    alert("Ini Latihan Javascript Pertama Saya!");
}

function pesanConsole() {
    console.log("It's Work");
}

function pesanDok() {
    document.write("Success<br>");
    document.write("<a href='m4-2.html'>Kembali</a>");
}